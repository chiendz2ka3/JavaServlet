create view vw_Customer_PhoneNumber as 
select Customer.FirstName,Customer.LastName , PhoneNumber.Number,PhoneNumber.RegisterDate 
from Customer inner join PhoneNumber on Customer.CusID = PhoneNumber.CusID
go

