create procedure sp_getAllCus @CusID int 
as 
select Number, RegisterDate from PhoneNumber where CusID = @CusID
go

