create procedure sp_delCus @CusID int
as 
delete from Customer where CusID = @CusID
go

